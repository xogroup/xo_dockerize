#!/usr/bin/env bash

bundle exec rspec

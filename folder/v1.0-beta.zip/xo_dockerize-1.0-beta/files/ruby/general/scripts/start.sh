#!/usr/bin/env bash

bundle exec rails s

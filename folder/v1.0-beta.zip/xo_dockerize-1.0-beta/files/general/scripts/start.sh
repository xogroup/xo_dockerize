#!/usr/bin/env bash

echo "Application start (rails s, npm start)"

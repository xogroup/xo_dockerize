#!/usr/bin/env bash

echo "Run your tests (Rspec, Karma, etc)"
